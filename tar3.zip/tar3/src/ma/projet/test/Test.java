
package ma.projet.test;

import java.util.Date;
import ma.projet.beans.Femme;
import ma.projet.beans.Homme;
import ma.projet.beans.Mariage;
import ma.projet.beans.MariagePK;
import ma.projet.services.FemmeService;
import ma.projet.services.HommeService;
import ma.projet.services.MariageService;
import ma.projet.util.HibernateUtil;


public class Test {

    public static void main(String[] args) {
        FemmeService ff = new FemmeService();
        HommeService hh = new HommeService();
        MariageService ms = new MariageService();
        
        System.out.println("\n********************************* allimentation de la base de donnees***************************\n");
        
        Femme f1 = new Femme("assia", "assia", "069635805368", "Casablanca", new Date("2001/02/03"));
        Femme f2 = new Femme("Amina", "Amina", "060232187952", "Marrakech", new Date("97/04/15"));
        Femme f3 = new Femme("hakima", "hakima", "062345678912", "Rabat", new Date("92/06/22"));
        Femme f4 = new Femme("inass", "inass", "067890123456", "Tangier", new Date("98/09/10"));
        Femme f5 = new Femme("Lina", "Lina", "063402353423", "Agadir", new Date("2002/11/30"));
        Femme f6 = new Femme("ilham", "ilham", "068760232189", "Fes", new Date("2003/01/25"));
        Femme f7 = new Femme("fatima", "fatima", "060232188752", "Tetouan", new Date("96/06/06"));
        Femme f8 = new Femme("loubna", "loubna", "061234569876", "Meknes", new Date("94/03/18"));
        Femme f9 = new Femme("sara", "sara", "060232126787", "Oujda", new Date("99/06/12"));
        Femme f10 = new Femme("nour", "nour", "064567890123", "Kenitra", new Date("80/12/04"));

        Homme h1 = new Homme("akram", "akram", "0612345678", "Casablanca", new Date("90/05/15"));
        Homme h2 = new Homme("simo", "simo", "0602321098", "Marrakech", new Date("2004/10/20"));
        Homme h3 = new Homme("Khalid", "Khalid", "0678901234", "Rabat", new Date("2006/03/30"));
        Homme h4 = new Homme("mehdi", "mehdi", "0612345678", "Tangier", new Date("2003/09/25"));
        Homme h5 = new Homme("Youssef", "Youssef", "0645678901", "Agadir", new Date("2000/06/06"));

        ff.create(f1);
        ff.create(f2);
        ff.create(f3);
        ff.create(f4);
        ff.create(f5);
        ff.create(f6);
        ff.create(f7);
        ff.create(f8);
        ff.create(f9);
        ff.create(f10);

        hh.create(h1);
        hh.create(h2);
        hh.create(h3);
        hh.create(h4);
        hh.create(h5);

        MariagePK mpk1 = new MariagePK(1, 12, new Date("123/03/09"));
        MariagePK mpk2 = new MariagePK(5, 13, new Date("120/06/06"));
        MariagePK mpk3 = new MariagePK(6, 14, new Date("121/03/09"));
        MariagePK mpk4 = new MariagePK(2, 11, new Date("116/06/06"));
        MariagePK mpk5 = new MariagePK(4, 11, new Date("122/06/06"));
        MariagePK mpk6 = new MariagePK(7, 11, new Date("118/06/06"));
        MariagePK mpk7 = new MariagePK(9, 11, new Date("117/06/06"));

        Mariage m1 = new Mariage(mpk1, null, 3);
        Mariage m2 = new Mariage(mpk2, new Date("2023/06/11"), 2);
        Mariage m3 = new Mariage(mpk3, null, 3);
        Mariage m4 = new Mariage(mpk4, new Date("2019/06/12"), 1);
        Mariage m5 = new Mariage(mpk5, new Date("2023/01/01"), 3);
        Mariage m6 = new Mariage(mpk6, new Date("2020/06/01"), 3);
        Mariage m7 = new Mariage(mpk7, new Date("2018/04/15"), 3);

        ms.create(m1);
        ms.create(m2);
        ms.create(m3);
        ms.create(m4);
        ms.create(m5);
        ms.create(m6);
        ms.create(m7);

    System.out.println("\n*********************************all femmes ***************************\n");
    
    
        for (Femme f : ff.getAll()) {
            System.out.println(f);
        }
        
        
    System.out.println("\n********************************* la Femme La Plus Agee***************************\n");
    
    
        System.out.println(ff.getFemmeLaPlusAgee().getNom());
        
        
    System.out.println("\n****************************Epouses Par Homme***************************\n");
    
    
        hh.getEpousesParHomme(hh.getById(13));
        
        
    System.out.println("\n****************************Nombre Enfants Entre Dates***************************\n");
    
    
        System.out.println(ff.getNombreEnfantsEntreDates(2, new Date("2018/06/12"), new Date("2023/06/12")));
        
        
    System.out.println("\n****************************Femmes Mariees Deux Fois***************************\n");
    
    
        for (Femme fem : ff.getFemmesMarieesDeuxFoisOuPlus()) {
            System.out.println(fem);
        }
        
        
    System.out.println("\n****************************hommes Maries Par Quatre Femmes Entre Dates**************************\n");
    
    
        hh.getHommesMariesParQuatreFemmesEntreDates(new Date("2000/01/01"), new Date("2024/01/01"));
        
        
    System.out.println("\n****************************Mariages By Homme**************************\n");
    
    
        for (Mariage m : hh.getMariagesByHomme(hh.getById(11))) {
            System.out.println(m);
        }
    }

}